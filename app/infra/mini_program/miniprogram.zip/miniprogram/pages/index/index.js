Page({
  data: {
    scene_id: '',
    status: 'Ready to scan', // 初始状态
    isLogining: false,
    userInfo: null
  },

  onLoad: function (options) {
    // 1. 捕获扫码参数
    let scene = '';
    if (options.scene) {
      scene = decodeURIComponent(options.scene);
    } else if (options.q) {
      // 兼容普通二维码
      let q = decodeURIComponent(options.q);
      const match = q.match(/[?&]scene=([^&]+)/);
      scene = match ? match[1] : '';
    }

    if (scene) {
      this.setData({ 
        scene_id: scene,
        status: '情报链接已建立' 
      });
      // 这里的逻辑：如果有scene_id，用户点击按钮触发 handleLogin
    } else {
      this.setData({ status: '请从PC端扫码进入' });
    }
  },

  handleLogin: function () {
    if (!this.data.scene_id) {
      wx.showModal({
        title: '提示',
        content: '未检测到登录场景，请在电脑端刷新二维码重新扫描',
        showCancel: false,
        confirmColor: '#2C3E50'
      });
      return;
    }

    this.setData({ isLogining: true });
    wx.showLoading({ title: '同步情报中...' });

    wx.login({
      success: (res) => {
        if (res.code) {
          wx.request({
            url: 'https://api.videotl.com/auth/wechat/confirm',
            //url: 'http://127.0.0.1:8000/auth/wechat/confirm',
            method: 'POST',
            header: { 'content-type': 'application/json' },
            data: {
              scene_id: this.data.scene_id,
              code: res.code
            },
            success: (resp) => {
              if (resp.statusCode === 200) {
                wx.showToast({ title: '授权成功', icon: 'success' });
                this.setData({ status: '登录成功，正在返回网页' });
                // 延迟关闭，给用户一个反馈时间
                setTimeout(() => { wx.exitMiniProgram(); }, 2000);
              } else {
                wx.showModal({ 
                  title: '授权失败', 
                  content: resp.data.detail || '情报站暂时无法连接',
                  showCancel: false
                });
              }
            },
            fail: () => {
              wx.showModal({ title: '连接超时', content: '请检查网络或服务器状态' });
            },
            complete: () => {
              wx.hideLoading();
              this.setData({ isLogining: false });
            }
          });
        }
      },
      fail: () => {
        this.setData({ isLogining: false });
        wx.hideLoading();
      }
    });
  }
})